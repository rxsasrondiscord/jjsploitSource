﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sxlib.Specialized;
using sxlib;
using System.Windows.Forms;
using System.IO;

namespace KJhrh8Yh9iohUHFIU_2
{
    public partial class Form1 : Form
    {
        public bool Attached;
        public bool Loaded;
        public static string Direct = Directory.GetCurrentDirectory();
        public Form1()
        {
            InitializeComponent();

            Functions.Lib = SxLib.InitializeWinForms(this, Direct);
            Functions.Lib.Load();
            Functions.Lib.LoadEvent += SynLoadEvent;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Functions.Lib.Attach();
            Functions.Lib.AttachEvent += SynAttachEvent;
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            foreach (Process robloxProcess in Process.GetProcessesByName("KJhrh8Yh9iohUHFIU$2"))
                robloxProcess.Kill();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            foreach (Process robloxProcess in Process.GetProcessesByName("KJhrh8Yh9iohUHFIU$2"))
                robloxProcess.Kill();
        }

        private void SynLoadEvent(SxLibBase.SynLoadEvents Event, object Param)
        {
            switch(Event)
            {

            }
        }

        private void SynAttachEvent(SxLibBase.SynAttachEvents Event, object Param)
        {
            switch (Event)
            {
                case SxLibBase.SynAttachEvents.READY:
                    attachmainpanel.Visible = false;
                    attachtoppanel.Visible = false;

                    mainpanel.Visible = true;
                    topmainpanel.Visible = true;
                    return;
            }
        }

        private void executebtn_Click(object sender, EventArgs e)
        {
            string script = this.executebox.Text;
            Functions.Lib.Execute(script);
        }

        private void openfilebtn_Click(object sender, EventArgs e)
        {
            OpenFileDialog opendialogfile = new OpenFileDialog();
            opendialogfile.Filter = "Lua File (*.lua)|*.lua|Text File (*.txt)|*.txt";
            opendialogfile.FilterIndex = 2;
            opendialogfile.RestoreDirectory = true;
            if (opendialogfile.ShowDialog() != DialogResult.OK)
                return;
            try
            {
                executebox.Text = "";
                System.IO.Stream stream;
                if ((stream = opendialogfile.OpenFile()) == null)
                    return;
                using (stream)
                    this.executebox.Text = System.IO.File.ReadAllText(opendialogfile.FileName);
            }
            catch (Exception)
            {
                int num = (int)MessageBox.Show("An unexpected error has occured", "OOF!", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            CommandsPanel.Visible = false;
            ButtonsPanel.Visible = false;
            LuaPanel.Visible = true;
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void ctrltpbtn_Click(object sender, EventArgs e)
        {
            string script = this.ctrltpbox.Text;
            Functions.Lib.Execute(script);
        }

        private void infjumpbtn_Click(object sender, EventArgs e)
        {
            string script = this.infjumpbox.Text;
            Functions.Lib.Execute(script);
        }

        private void espbtn_Click(object sender, EventArgs e)
        {
            string script = this.espbox.Text;
            Functions.Lib.Execute(script);
        }

        private void ButtonsPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flybtn_Click(object sender, EventArgs e)
        {
            string script = this.flybox.Text;
            Functions.Lib.Execute(script);
        }

        private void godbtn_Click(object sender, EventArgs e)
        {
            string script = this.godmodebox.Text;
            Functions.Lib.Execute(script);
        }

        private void noclipbtn_Click(object sender, EventArgs e)
        {
            string script = this.noclipbox.Text;
            Functions.Lib.Execute(script);
        }

        private void flashbtn_Click(object sender, EventArgs e)
        {
            string script = this.flashlightbox.Text;
            Functions.Lib.Execute(script);
        }

        private void nolegbtn_Click(object sender, EventArgs e)
        {
            string script = this.nolegsbox.Text;
            Functions.Lib.Execute(script);
        }

        private void floatbtn_Click(object sender, EventArgs e)
        {
            string script = this.floatbox.Text;
            Functions.Lib.Execute(script);
        }

        private void ctbtn_Click(object sender, EventArgs e)
        {
            string script = this.chattrollbox.Text;
            Functions.Lib.Execute(script);
        }

        private void suicidebtn_Click(object sender, EventArgs e)
        {
            string script = this.suicidebox.Text;
            Functions.Lib.Execute(script);
        }

        private void btoolsbtn_Click(object sender, EventArgs e)
        {
            string script = this.btoolsbox.Text;
            Functions.Lib.Execute(script);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            CommandsPanel.Visible = false;
            ButtonsPanel.Visible = true;
            LuaPanel.Visible = false;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            CommandsPanel.Visible = true;
            ButtonsPanel.Visible = false;
            LuaPanel.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (Process robloxProcess in Process.GetProcessesByName("RobloxPlayerBeta"))
                robloxProcess.Kill();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            foreach (Process robloxProcess in Process.GetProcessesByName("RobloxPlayerBeta"))
                robloxProcess.Kill();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.TopMost ^= true;
           if (this.TopMost == false)
            {
                button2.BackColor = Color.Red;
            }
            else
            {
                button2.BackColor = Color.FromArgb(46, 171, 95);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.TopMost ^= true;
            if (this.TopMost == false)
            {
                button8.BackColor = Color.Red;
            }
            else
            {
                button8.BackColor = Color.FromArgb(46, 171, 95);
            }
        }
    }
}
