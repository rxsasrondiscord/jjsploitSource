﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sxlib.Specialized;

namespace KJhrh8Yh9iohUHFIU_2
{
    class Functions
    {
        public static SxLibWinForms Lib;
    }
}
