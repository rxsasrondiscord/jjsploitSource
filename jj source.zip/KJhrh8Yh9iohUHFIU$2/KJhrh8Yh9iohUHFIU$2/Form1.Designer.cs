﻿
namespace KJhrh8Yh9iohUHFIU_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.attachmainpanel = new System.Windows.Forms.Panel();
            this.etbtn = new System.Windows.Forms.Button();
            this.ltcbtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.attachbtn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.attachtoppanel = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse2 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel4 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.topmainpanel = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.mainpanel = new System.Windows.Forms.Panel();
            this.button12 = new System.Windows.Forms.Button();
            this.ButtonsPanel = new System.Windows.Forms.Panel();
            this.btoolsbtn = new System.Windows.Forms.Button();
            this.suicidebtn = new System.Windows.Forms.Button();
            this.floatbtn = new System.Windows.Forms.Button();
            this.ctbtn = new System.Windows.Forms.Button();
            this.nolegbtn = new System.Windows.Forms.Button();
            this.flashbtn = new System.Windows.Forms.Button();
            this.noclipbtn = new System.Windows.Forms.Button();
            this.godbtn = new System.Windows.Forms.Button();
            this.flybtn = new System.Windows.Forms.Button();
            this.espbtn = new System.Windows.Forms.Button();
            this.infjumpbtn = new System.Windows.Forms.Button();
            this.ctrltpbtn = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.CommandsPanel = new System.Windows.Forms.Panel();
            this.LuaPanel = new System.Windows.Forms.Panel();
            this.executebox = new FastColoredTextBoxNS.FastColoredTextBox();
            this.openfilebtn = new System.Windows.Forms.Button();
            this.executebtn = new System.Windows.Forms.Button();
            this.bunifuElipse3 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse4 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuDragControl2 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.ctrltpbox = new System.Windows.Forms.RichTextBox();
            this.infjumpbox = new System.Windows.Forms.RichTextBox();
            this.espbox = new System.Windows.Forms.RichTextBox();
            this.flybox = new System.Windows.Forms.RichTextBox();
            this.godmodebox = new System.Windows.Forms.RichTextBox();
            this.noclipbox = new System.Windows.Forms.RichTextBox();
            this.flashlightbox = new System.Windows.Forms.RichTextBox();
            this.nolegsbox = new System.Windows.Forms.RichTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.floatbox = new System.Windows.Forms.RichTextBox();
            this.btoolsbox = new System.Windows.Forms.RichTextBox();
            this.suicidebox = new System.Windows.Forms.RichTextBox();
            this.chattrollbox = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.attachmainpanel.SuspendLayout();
            this.panel2.SuspendLayout();
            this.attachtoppanel.SuspendLayout();
            this.panel4.SuspendLayout();
            this.topmainpanel.SuspendLayout();
            this.mainpanel.SuspendLayout();
            this.ButtonsPanel.SuspendLayout();
            this.CommandsPanel.SuspendLayout();
            this.LuaPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.executebox)).BeginInit();
            this.SuspendLayout();
            // 
            // attachmainpanel
            // 
            this.attachmainpanel.BackColor = System.Drawing.Color.White;
            this.attachmainpanel.Controls.Add(this.chattrollbox);
            this.attachmainpanel.Controls.Add(this.label8);
            this.attachmainpanel.Controls.Add(this.flashlightbox);
            this.attachmainpanel.Controls.Add(this.suicidebox);
            this.attachmainpanel.Controls.Add(this.noclipbox);
            this.attachmainpanel.Controls.Add(this.etbtn);
            this.attachmainpanel.Controls.Add(this.godmodebox);
            this.attachmainpanel.Controls.Add(this.btoolsbox);
            this.attachmainpanel.Controls.Add(this.flybox);
            this.attachmainpanel.Controls.Add(this.ltcbtn);
            this.attachmainpanel.Controls.Add(this.espbox);
            this.attachmainpanel.Controls.Add(this.floatbox);
            this.attachmainpanel.Controls.Add(this.infjumpbox);
            this.attachmainpanel.Controls.Add(this.label4);
            this.attachmainpanel.Controls.Add(this.ctrltpbox);
            this.attachmainpanel.Controls.Add(this.nolegsbox);
            this.attachmainpanel.Controls.Add(this.attachbtn);
            this.attachmainpanel.Controls.Add(this.panel2);
            this.attachmainpanel.Location = new System.Drawing.Point(54, 82);
            this.attachmainpanel.Name = "attachmainpanel";
            this.attachmainpanel.Size = new System.Drawing.Size(505, 274);
            this.attachmainpanel.TabIndex = 0;
            // 
            // etbtn
            // 
            this.etbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(76)))), ((int)(((byte)(64)))));
            this.etbtn.FlatAppearance.BorderSize = 0;
            this.etbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.etbtn.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.etbtn.ForeColor = System.Drawing.Color.White;
            this.etbtn.Location = new System.Drawing.Point(336, 193);
            this.etbtn.Name = "etbtn";
            this.etbtn.Size = new System.Drawing.Size(137, 48);
            this.etbtn.TabIndex = 8;
            this.etbtn.Text = "Exploit \r\nTutorials\r\n";
            this.etbtn.UseVisualStyleBackColor = false;
            // 
            // ltcbtn
            // 
            this.ltcbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(76)))), ((int)(((byte)(64)))));
            this.ltcbtn.FlatAppearance.BorderSize = 0;
            this.ltcbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ltcbtn.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ltcbtn.ForeColor = System.Drawing.Color.White;
            this.ltcbtn.Location = new System.Drawing.Point(32, 193);
            this.ltcbtn.Name = "ltcbtn";
            this.ltcbtn.Size = new System.Drawing.Size(134, 48);
            this.ltcbtn.TabIndex = 7;
            this.ltcbtn.Text = "Learn To Code";
            this.ltcbtn.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(71, 54);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(379, 30);
            this.label4.TabIndex = 6;
            this.label4.Text = "You must attach JJSploit to a game first";
            // 
            // attachbtn
            // 
            this.attachbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.attachbtn.FlatAppearance.BorderSize = 0;
            this.attachbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.attachbtn.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attachbtn.ForeColor = System.Drawing.Color.White;
            this.attachbtn.Location = new System.Drawing.Point(67, 126);
            this.attachbtn.Name = "attachbtn";
            this.attachbtn.Size = new System.Drawing.Size(376, 40);
            this.attachbtn.TabIndex = 5;
            this.attachbtn.Text = "Attach";
            this.attachbtn.UseVisualStyleBackColor = false;
            this.attachbtn.Click += new System.EventHandler(this.button4_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(0, 246);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(505, 28);
            this.panel2.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(453, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 19);
            this.label3.TabIndex = 7;
            this.label3.Text = "v5.2.3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(208, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 19);
            this.label2.TabIndex = 6;
            this.label2.Text = "wearedevs.net";
            // 
            // attachtoppanel
            // 
            this.attachtoppanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.attachtoppanel.Controls.Add(this.button3);
            this.attachtoppanel.Controls.Add(this.button2);
            this.attachtoppanel.Controls.Add(this.button1);
            this.attachtoppanel.Controls.Add(this.label1);
            this.attachtoppanel.Location = new System.Drawing.Point(54, 82);
            this.attachtoppanel.Name = "attachtoppanel";
            this.attachtoppanel.Size = new System.Drawing.Size(505, 30);
            this.attachtoppanel.TabIndex = 1;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(44)))), ((int)(((byte)(48)))));
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(108)))));
            this.button3.Location = new System.Drawing.Point(477, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(28, 29);
            this.button3.TabIndex = 5;
            this.button3.Text = "X";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(400, -1);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(76, 31);
            this.button2.TabIndex = 4;
            this.button2.Text = "Top Most";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(44)))), ((int)(((byte)(48)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(108)))));
            this.button1.Location = new System.Drawing.Point(318, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(80, 29);
            this.button1.TabIndex = 3;
            this.button1.Text = "Fix Roblox";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "JJSploit";
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.attachtoppanel;
            this.bunifuDragControl1.Vertical = true;
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 7;
            this.bunifuElipse1.TargetControl = this.ltcbtn;
            // 
            // bunifuElipse2
            // 
            this.bunifuElipse2.ElipseRadius = 7;
            this.bunifuElipse2.TargetControl = this.etbtn;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Location = new System.Drawing.Point(0, 246);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(505, 28);
            this.panel4.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(453, 5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 19);
            this.label5.TabIndex = 7;
            this.label5.Text = "v5.2.3";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(208, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 19);
            this.label6.TabIndex = 6;
            this.label6.Text = "wearedevs.net";
            // 
            // topmainpanel
            // 
            this.topmainpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.topmainpanel.Controls.Add(this.button7);
            this.topmainpanel.Controls.Add(this.button8);
            this.topmainpanel.Controls.Add(this.button9);
            this.topmainpanel.Controls.Add(this.label7);
            this.topmainpanel.Location = new System.Drawing.Point(0, 0);
            this.topmainpanel.Name = "topmainpanel";
            this.topmainpanel.Size = new System.Drawing.Size(505, 27);
            this.topmainpanel.TabIndex = 3;
            this.topmainpanel.Visible = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(44)))), ((int)(((byte)(48)))));
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(108)))));
            this.button7.Location = new System.Drawing.Point(476, 0);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(28, 27);
            this.button7.TabIndex = 5;
            this.button7.Text = "X";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Red;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(398, -1);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(76, 29);
            this.button8.TabIndex = 4;
            this.button8.Text = "Top Most";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(44)))), ((int)(((byte)(48)))));
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(108)))));
            this.button9.Location = new System.Drawing.Point(316, 0);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(80, 27);
            this.button9.TabIndex = 3;
            this.button9.Text = "Fix Roblox";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(6, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 19);
            this.label7.TabIndex = 0;
            this.label7.Text = "JJSploit";
            // 
            // mainpanel
            // 
            this.mainpanel.BackColor = System.Drawing.Color.White;
            this.mainpanel.Controls.Add(this.topmainpanel);
            this.mainpanel.Controls.Add(this.button12);
            this.mainpanel.Controls.Add(this.CommandsPanel);
            this.mainpanel.Controls.Add(this.LuaPanel);
            this.mainpanel.Controls.Add(this.ButtonsPanel);
            this.mainpanel.Controls.Add(this.button11);
            this.mainpanel.Controls.Add(this.button10);
            this.mainpanel.Controls.Add(this.panel4);
            this.mainpanel.Location = new System.Drawing.Point(54, 362);
            this.mainpanel.Name = "mainpanel";
            this.mainpanel.Size = new System.Drawing.Size(505, 274);
            this.mainpanel.TabIndex = 2;
            this.mainpanel.Visible = false;
            // 
            // button12
            // 
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.button12.Location = new System.Drawing.Point(336, 28);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(169, 30);
            this.button12.TabIndex = 5;
            this.button12.Text = "Lua";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // ButtonsPanel
            // 
            this.ButtonsPanel.BackColor = System.Drawing.Color.White;
            this.ButtonsPanel.Controls.Add(this.btoolsbtn);
            this.ButtonsPanel.Controls.Add(this.suicidebtn);
            this.ButtonsPanel.Controls.Add(this.floatbtn);
            this.ButtonsPanel.Controls.Add(this.ctbtn);
            this.ButtonsPanel.Controls.Add(this.nolegbtn);
            this.ButtonsPanel.Controls.Add(this.flashbtn);
            this.ButtonsPanel.Controls.Add(this.noclipbtn);
            this.ButtonsPanel.Controls.Add(this.godbtn);
            this.ButtonsPanel.Controls.Add(this.flybtn);
            this.ButtonsPanel.Controls.Add(this.espbtn);
            this.ButtonsPanel.Controls.Add(this.infjumpbtn);
            this.ButtonsPanel.Controls.Add(this.ctrltpbtn);
            this.ButtonsPanel.Controls.Add(this.label9);
            this.ButtonsPanel.Location = new System.Drawing.Point(7, 59);
            this.ButtonsPanel.Name = "ButtonsPanel";
            this.ButtonsPanel.Size = new System.Drawing.Size(490, 185);
            this.ButtonsPanel.TabIndex = 4;
            this.ButtonsPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.ButtonsPanel_Paint);
            // 
            // btoolsbtn
            // 
            this.btoolsbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(19)))), ((int)(((byte)(22)))));
            this.btoolsbtn.FlatAppearance.BorderSize = 0;
            this.btoolsbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btoolsbtn.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btoolsbtn.ForeColor = System.Drawing.Color.White;
            this.btoolsbtn.Location = new System.Drawing.Point(308, 154);
            this.btoolsbtn.Name = "btoolsbtn";
            this.btoolsbtn.Size = new System.Drawing.Size(101, 28);
            this.btoolsbtn.TabIndex = 32;
            this.btoolsbtn.Text = "Btools";
            this.btoolsbtn.UseVisualStyleBackColor = false;
            this.btoolsbtn.Click += new System.EventHandler(this.btoolsbtn_Click);
            // 
            // suicidebtn
            // 
            this.suicidebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(19)))), ((int)(((byte)(22)))));
            this.suicidebtn.FlatAppearance.BorderSize = 0;
            this.suicidebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.suicidebtn.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.suicidebtn.ForeColor = System.Drawing.Color.White;
            this.suicidebtn.Location = new System.Drawing.Point(200, 154);
            this.suicidebtn.Name = "suicidebtn";
            this.suicidebtn.Size = new System.Drawing.Size(101, 28);
            this.suicidebtn.TabIndex = 31;
            this.suicidebtn.Text = "Suicide";
            this.suicidebtn.UseVisualStyleBackColor = false;
            this.suicidebtn.Click += new System.EventHandler(this.suicidebtn_Click);
            // 
            // floatbtn
            // 
            this.floatbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(19)))), ((int)(((byte)(22)))));
            this.floatbtn.FlatAppearance.BorderSize = 0;
            this.floatbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.floatbtn.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.floatbtn.ForeColor = System.Drawing.Color.White;
            this.floatbtn.Location = new System.Drawing.Point(308, 117);
            this.floatbtn.Name = "floatbtn";
            this.floatbtn.Size = new System.Drawing.Size(101, 28);
            this.floatbtn.TabIndex = 29;
            this.floatbtn.Text = "Float";
            this.floatbtn.UseVisualStyleBackColor = false;
            this.floatbtn.Click += new System.EventHandler(this.floatbtn_Click);
            // 
            // ctbtn
            // 
            this.ctbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(19)))), ((int)(((byte)(22)))));
            this.ctbtn.FlatAppearance.BorderSize = 0;
            this.ctbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ctbtn.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctbtn.ForeColor = System.Drawing.Color.White;
            this.ctbtn.Location = new System.Drawing.Point(91, 154);
            this.ctbtn.Name = "ctbtn";
            this.ctbtn.Size = new System.Drawing.Size(101, 28);
            this.ctbtn.TabIndex = 30;
            this.ctbtn.Text = "Chat Troll";
            this.ctbtn.UseVisualStyleBackColor = false;
            this.ctbtn.Click += new System.EventHandler(this.ctbtn_Click);
            // 
            // nolegbtn
            // 
            this.nolegbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(19)))), ((int)(((byte)(22)))));
            this.nolegbtn.FlatAppearance.BorderSize = 0;
            this.nolegbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nolegbtn.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nolegbtn.ForeColor = System.Drawing.Color.White;
            this.nolegbtn.Location = new System.Drawing.Point(200, 117);
            this.nolegbtn.Name = "nolegbtn";
            this.nolegbtn.Size = new System.Drawing.Size(101, 28);
            this.nolegbtn.TabIndex = 28;
            this.nolegbtn.Text = "No Legs";
            this.nolegbtn.UseVisualStyleBackColor = false;
            this.nolegbtn.Click += new System.EventHandler(this.nolegbtn_Click);
            // 
            // flashbtn
            // 
            this.flashbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(19)))), ((int)(((byte)(22)))));
            this.flashbtn.FlatAppearance.BorderSize = 0;
            this.flashbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.flashbtn.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flashbtn.ForeColor = System.Drawing.Color.White;
            this.flashbtn.Location = new System.Drawing.Point(91, 117);
            this.flashbtn.Name = "flashbtn";
            this.flashbtn.Size = new System.Drawing.Size(101, 28);
            this.flashbtn.TabIndex = 27;
            this.flashbtn.Text = "Flashlight";
            this.flashbtn.UseVisualStyleBackColor = false;
            this.flashbtn.Click += new System.EventHandler(this.flashbtn_Click);
            // 
            // noclipbtn
            // 
            this.noclipbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(19)))), ((int)(((byte)(22)))));
            this.noclipbtn.FlatAppearance.BorderSize = 0;
            this.noclipbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.noclipbtn.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noclipbtn.ForeColor = System.Drawing.Color.White;
            this.noclipbtn.Location = new System.Drawing.Point(308, 80);
            this.noclipbtn.Name = "noclipbtn";
            this.noclipbtn.Size = new System.Drawing.Size(101, 28);
            this.noclipbtn.TabIndex = 26;
            this.noclipbtn.Text = "Noclip";
            this.noclipbtn.UseVisualStyleBackColor = false;
            this.noclipbtn.Click += new System.EventHandler(this.noclipbtn_Click);
            // 
            // godbtn
            // 
            this.godbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(19)))), ((int)(((byte)(22)))));
            this.godbtn.FlatAppearance.BorderSize = 0;
            this.godbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.godbtn.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.godbtn.ForeColor = System.Drawing.Color.White;
            this.godbtn.Location = new System.Drawing.Point(200, 80);
            this.godbtn.Name = "godbtn";
            this.godbtn.Size = new System.Drawing.Size(101, 28);
            this.godbtn.TabIndex = 25;
            this.godbtn.Text = "God mode";
            this.godbtn.UseVisualStyleBackColor = false;
            this.godbtn.Click += new System.EventHandler(this.godbtn_Click);
            // 
            // flybtn
            // 
            this.flybtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(19)))), ((int)(((byte)(22)))));
            this.flybtn.FlatAppearance.BorderSize = 0;
            this.flybtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.flybtn.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flybtn.ForeColor = System.Drawing.Color.White;
            this.flybtn.Location = new System.Drawing.Point(91, 80);
            this.flybtn.Name = "flybtn";
            this.flybtn.Size = new System.Drawing.Size(101, 28);
            this.flybtn.TabIndex = 24;
            this.flybtn.Text = "Fly";
            this.flybtn.UseVisualStyleBackColor = false;
            this.flybtn.Click += new System.EventHandler(this.flybtn_Click);
            // 
            // espbtn
            // 
            this.espbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(19)))), ((int)(((byte)(22)))));
            this.espbtn.FlatAppearance.BorderSize = 0;
            this.espbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.espbtn.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.espbtn.ForeColor = System.Drawing.Color.White;
            this.espbtn.Location = new System.Drawing.Point(308, 42);
            this.espbtn.Name = "espbtn";
            this.espbtn.Size = new System.Drawing.Size(101, 28);
            this.espbtn.TabIndex = 23;
            this.espbtn.Text = "ESP";
            this.espbtn.UseVisualStyleBackColor = false;
            this.espbtn.Click += new System.EventHandler(this.espbtn_Click);
            // 
            // infjumpbtn
            // 
            this.infjumpbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(19)))), ((int)(((byte)(22)))));
            this.infjumpbtn.FlatAppearance.BorderSize = 0;
            this.infjumpbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.infjumpbtn.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.infjumpbtn.ForeColor = System.Drawing.Color.White;
            this.infjumpbtn.Location = new System.Drawing.Point(200, 42);
            this.infjumpbtn.Name = "infjumpbtn";
            this.infjumpbtn.Size = new System.Drawing.Size(101, 28);
            this.infjumpbtn.TabIndex = 22;
            this.infjumpbtn.Text = "Infinite Jump";
            this.infjumpbtn.UseVisualStyleBackColor = false;
            this.infjumpbtn.Click += new System.EventHandler(this.infjumpbtn_Click);
            // 
            // ctrltpbtn
            // 
            this.ctrltpbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(19)))), ((int)(((byte)(22)))));
            this.ctrltpbtn.FlatAppearance.BorderSize = 0;
            this.ctrltpbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ctrltpbtn.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctrltpbtn.ForeColor = System.Drawing.Color.White;
            this.ctrltpbtn.Location = new System.Drawing.Point(91, 42);
            this.ctrltpbtn.Name = "ctrltpbtn";
            this.ctrltpbtn.Size = new System.Drawing.Size(101, 28);
            this.ctrltpbtn.TabIndex = 21;
            this.ctrltpbtn.Text = "ctrl+click tp";
            this.ctrltpbtn.UseVisualStyleBackColor = false;
            this.ctrltpbtn.Click += new System.EventHandler(this.ctrltpbtn_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Yu Gothic UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(198, 5);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 32);
            this.label9.TabIndex = 20;
            this.label9.Text = "Common";
            // 
            // button11
            // 
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.button11.Location = new System.Drawing.Point(168, 28);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(168, 30);
            this.button11.TabIndex = 4;
            this.button11.Text = "Commands";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Location = new System.Drawing.Point(0, 28);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(168, 30);
            this.button10.TabIndex = 3;
            this.button10.Text = "Buttons";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // CommandsPanel
            // 
            this.CommandsPanel.BackColor = System.Drawing.Color.White;
            this.CommandsPanel.Controls.Add(this.label10);
            this.CommandsPanel.Location = new System.Drawing.Point(7, 59);
            this.CommandsPanel.Name = "CommandsPanel";
            this.CommandsPanel.Size = new System.Drawing.Size(495, 182);
            this.CommandsPanel.TabIndex = 5;
            this.CommandsPanel.Visible = false;
            // 
            // LuaPanel
            // 
            this.LuaPanel.BackColor = System.Drawing.Color.White;
            this.LuaPanel.Controls.Add(this.executebox);
            this.LuaPanel.Controls.Add(this.openfilebtn);
            this.LuaPanel.Controls.Add(this.executebtn);
            this.LuaPanel.Location = new System.Drawing.Point(5, 59);
            this.LuaPanel.Name = "LuaPanel";
            this.LuaPanel.Size = new System.Drawing.Size(493, 186);
            this.LuaPanel.TabIndex = 6;
            this.LuaPanel.Visible = false;
            // 
            // executebox
            // 
            this.executebox.AutoCompleteBracketsList = new char[] {
        '(',
        ')',
        '{',
        '}',
        '[',
        ']',
        '\"',
        '\"',
        '\'',
        '\''};
            this.executebox.AutoIndentCharsPatterns = "\r\n^\\s*[\\w\\.]+(\\s\\w+)?\\s*(?<range>=)\\s*(?<range>.+)\r\n";
            this.executebox.AutoScrollMinSize = new System.Drawing.Size(419, 28);
            this.executebox.BackBrush = null;
            this.executebox.BracketsHighlightStrategy = FastColoredTextBoxNS.BracketsHighlightStrategy.Strategy2;
            this.executebox.CharHeight = 14;
            this.executebox.CharWidth = 8;
            this.executebox.CommentPrefix = "--";
            this.executebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.executebox.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.executebox.Font = new System.Drawing.Font("Courier New", 9.75F);
            this.executebox.IsReplaceMode = false;
            this.executebox.Language = FastColoredTextBoxNS.Language.Lua;
            this.executebox.LeftBracket = '(';
            this.executebox.LeftBracket2 = '{';
            this.executebox.LineNumberColor = System.Drawing.Color.Black;
            this.executebox.Location = new System.Drawing.Point(5, 3);
            this.executebox.Name = "executebox";
            this.executebox.Paddings = new System.Windows.Forms.Padding(0);
            this.executebox.RightBracket = ')';
            this.executebox.RightBracket2 = '}';
            this.executebox.SelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.executebox.ServiceColors = ((FastColoredTextBoxNS.ServiceColors)(resources.GetObject("executebox.ServiceColors")));
            this.executebox.Size = new System.Drawing.Size(492, 145);
            this.executebox.TabIndex = 8;
            this.executebox.Text = "--Scripts that are too complicated will work!\r\n--The executor does receive freque" +
    "nt improvements";
            this.executebox.Zoom = 100;
            // 
            // openfilebtn
            // 
            this.openfilebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.openfilebtn.FlatAppearance.BorderSize = 0;
            this.openfilebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.openfilebtn.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.openfilebtn.ForeColor = System.Drawing.Color.White;
            this.openfilebtn.Location = new System.Drawing.Point(307, 150);
            this.openfilebtn.Name = "openfilebtn";
            this.openfilebtn.Size = new System.Drawing.Size(124, 34);
            this.openfilebtn.TabIndex = 7;
            this.openfilebtn.Text = "Open File";
            this.openfilebtn.UseVisualStyleBackColor = false;
            this.openfilebtn.Click += new System.EventHandler(this.openfilebtn_Click);
            // 
            // executebtn
            // 
            this.executebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.executebtn.FlatAppearance.BorderSize = 0;
            this.executebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.executebtn.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.executebtn.ForeColor = System.Drawing.Color.White;
            this.executebtn.Location = new System.Drawing.Point(75, 150);
            this.executebtn.Name = "executebtn";
            this.executebtn.Size = new System.Drawing.Size(124, 34);
            this.executebtn.TabIndex = 6;
            this.executebtn.Text = "Execute";
            this.executebtn.UseVisualStyleBackColor = false;
            this.executebtn.Click += new System.EventHandler(this.executebtn_Click);
            // 
            // bunifuElipse3
            // 
            this.bunifuElipse3.ElipseRadius = 7;
            this.bunifuElipse3.TargetControl = this.executebtn;
            // 
            // bunifuElipse4
            // 
            this.bunifuElipse4.ElipseRadius = 7;
            this.bunifuElipse4.TargetControl = this.openfilebtn;
            // 
            // bunifuDragControl2
            // 
            this.bunifuDragControl2.Fixed = true;
            this.bunifuDragControl2.Horizontal = true;
            this.bunifuDragControl2.TargetControl = this.topmainpanel;
            this.bunifuDragControl2.Vertical = true;
            // 
            // ctrltpbox
            // 
            this.ctrltpbox.Location = new System.Drawing.Point(456, 64);
            this.ctrltpbox.Name = "ctrltpbox";
            this.ctrltpbox.Size = new System.Drawing.Size(10, 10);
            this.ctrltpbox.TabIndex = 7;
            this.ctrltpbox.Text = resources.GetString("ctrltpbox.Text");
            this.ctrltpbox.Visible = false;
            // 
            // infjumpbox
            // 
            this.infjumpbox.Location = new System.Drawing.Point(472, 64);
            this.infjumpbox.Name = "infjumpbox";
            this.infjumpbox.Size = new System.Drawing.Size(10, 10);
            this.infjumpbox.TabIndex = 8;
            this.infjumpbox.Text = resources.GetString("infjumpbox.Text");
            this.infjumpbox.Visible = false;
            // 
            // espbox
            // 
            this.espbox.Location = new System.Drawing.Point(488, 64);
            this.espbox.Name = "espbox";
            this.espbox.Size = new System.Drawing.Size(10, 10);
            this.espbox.TabIndex = 9;
            this.espbox.Text = resources.GetString("espbox.Text");
            this.espbox.Visible = false;
            // 
            // flybox
            // 
            this.flybox.Location = new System.Drawing.Point(456, 80);
            this.flybox.Name = "flybox";
            this.flybox.Size = new System.Drawing.Size(10, 10);
            this.flybox.TabIndex = 10;
            this.flybox.Text = resources.GetString("flybox.Text");
            this.flybox.Visible = false;
            // 
            // godmodebox
            // 
            this.godmodebox.Location = new System.Drawing.Point(472, 80);
            this.godmodebox.Name = "godmodebox";
            this.godmodebox.Size = new System.Drawing.Size(10, 10);
            this.godmodebox.TabIndex = 11;
            this.godmodebox.Text = "local player=game.Players.LocalPlayer.Character\nplayer.Humanoid:Remove()\nInstance" +
    ".new(\'Humanoid\',player)";
            this.godmodebox.Visible = false;
            // 
            // noclipbox
            // 
            this.noclipbox.Location = new System.Drawing.Point(488, 80);
            this.noclipbox.Name = "noclipbox";
            this.noclipbox.Size = new System.Drawing.Size(10, 10);
            this.noclipbox.TabIndex = 12;
            this.noclipbox.Text = resources.GetString("noclipbox.Text");
            this.noclipbox.Visible = false;
            // 
            // flashlightbox
            // 
            this.flashlightbox.Location = new System.Drawing.Point(456, 94);
            this.flashlightbox.Name = "flashlightbox";
            this.flashlightbox.Size = new System.Drawing.Size(10, 10);
            this.flashlightbox.TabIndex = 13;
            this.flashlightbox.Text = resources.GetString("flashlightbox.Text");
            this.flashlightbox.Visible = false;
            // 
            // nolegsbox
            // 
            this.nolegsbox.Location = new System.Drawing.Point(440, 87);
            this.nolegsbox.Name = "nolegsbox";
            this.nolegsbox.Size = new System.Drawing.Size(10, 10);
            this.nolegsbox.TabIndex = 14;
            this.nolegsbox.Text = resources.GetString("nolegsbox.Text");
            this.nolegsbox.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(167)))), ((int)(((byte)(167)))), ((int)(((byte)(167)))));
            this.label8.Location = new System.Drawing.Point(158, 84);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(182, 25);
            this.label8.TabIndex = 9;
            this.label8.Text = "Working as of Today";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // floatbox
            // 
            this.floatbox.Location = new System.Drawing.Point(456, 89);
            this.floatbox.Name = "floatbox";
            this.floatbox.Size = new System.Drawing.Size(10, 10);
            this.floatbox.TabIndex = 15;
            this.floatbox.Text = resources.GetString("floatbox.Text");
            this.floatbox.Visible = false;
            // 
            // btoolsbox
            // 
            this.btoolsbox.Location = new System.Drawing.Point(456, 103);
            this.btoolsbox.Name = "btoolsbox";
            this.btoolsbox.Size = new System.Drawing.Size(10, 10);
            this.btoolsbox.TabIndex = 16;
            this.btoolsbox.Text = "local tool3 = Instance.new(\"HopperBin\",game.Players.LocalPlayer.Backpack)\ntool3.B" +
    "inType = \"Hammer\"";
            this.btoolsbox.Visible = false;
            // 
            // suicidebox
            // 
            this.suicidebox.Location = new System.Drawing.Point(440, 103);
            this.suicidebox.Name = "suicidebox";
            this.suicidebox.Size = new System.Drawing.Size(10, 10);
            this.suicidebox.TabIndex = 17;
            this.suicidebox.Text = "game.Players.LocalPlayer.Character.Humanoid.Health = 0";
            this.suicidebox.Visible = false;
            // 
            // chattrollbox
            // 
            this.chattrollbox.Location = new System.Drawing.Point(456, 110);
            this.chattrollbox.Name = "chattrollbox";
            this.chattrollbox.Size = new System.Drawing.Size(10, 10);
            this.chattrollbox.TabIndex = 18;
            this.chattrollbox.Text = resources.GetString("chattrollbox.Text");
            this.chattrollbox.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(116, 22);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(251, 30);
            this.label10.TabIndex = 7;
            this.label10.Text = "im not adding commands";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(1409, 694);
            this.Controls.Add(this.mainpanel);
            this.Controls.Add(this.attachtoppanel);
            this.Controls.Add(this.attachmainpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.attachmainpanel.ResumeLayout(false);
            this.attachmainpanel.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.attachtoppanel.ResumeLayout(false);
            this.attachtoppanel.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.topmainpanel.ResumeLayout(false);
            this.topmainpanel.PerformLayout();
            this.mainpanel.ResumeLayout(false);
            this.ButtonsPanel.ResumeLayout(false);
            this.ButtonsPanel.PerformLayout();
            this.CommandsPanel.ResumeLayout(false);
            this.CommandsPanel.PerformLayout();
            this.LuaPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.executebox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel attachmainpanel;
        private System.Windows.Forms.Button attachbtn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel attachtoppanel;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private System.Windows.Forms.Button etbtn;
        private System.Windows.Forms.Button ltcbtn;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel topmainpanel;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel mainpanel;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Panel ButtonsPanel;
        private System.Windows.Forms.Button btoolsbtn;
        private System.Windows.Forms.Button suicidebtn;
        private System.Windows.Forms.Button floatbtn;
        private System.Windows.Forms.Button ctbtn;
        private System.Windows.Forms.Button nolegbtn;
        private System.Windows.Forms.Button flashbtn;
        private System.Windows.Forms.Button noclipbtn;
        private System.Windows.Forms.Button godbtn;
        private System.Windows.Forms.Button flybtn;
        private System.Windows.Forms.Button espbtn;
        private System.Windows.Forms.Button infjumpbtn;
        private System.Windows.Forms.Button ctrltpbtn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel CommandsPanel;
        private System.Windows.Forms.Panel LuaPanel;
        private FastColoredTextBoxNS.FastColoredTextBox executebox;
        private System.Windows.Forms.Button openfilebtn;
        private System.Windows.Forms.Button executebtn;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse3;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse4;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl2;
        private System.Windows.Forms.RichTextBox ctrltpbox;
        private System.Windows.Forms.RichTextBox infjumpbox;
        private System.Windows.Forms.RichTextBox espbox;
        private System.Windows.Forms.RichTextBox flybox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RichTextBox godmodebox;
        private System.Windows.Forms.RichTextBox noclipbox;
        private System.Windows.Forms.RichTextBox flashlightbox;
        private System.Windows.Forms.RichTextBox nolegsbox;
        private System.Windows.Forms.RichTextBox floatbox;
        private System.Windows.Forms.RichTextBox btoolsbox;
        private System.Windows.Forms.RichTextBox suicidebox;
        private System.Windows.Forms.RichTextBox chattrollbox;
        private System.Windows.Forms.Label label10;
    }
}

